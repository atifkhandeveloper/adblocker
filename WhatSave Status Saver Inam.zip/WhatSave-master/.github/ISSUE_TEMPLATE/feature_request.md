---
name: Feature Request
about: Suggest an idea that you think should be implemented.
title: ''
labels: enhancement
assignees: ''

---

**Describe the idea:**
Please try to be clear and concise so that it can be understood better.

**Do you want to develop the feature on your own?**
If you want to develop the feature yourself and then submit a PR, let us know. We will evaluate the proposal to take it into consideration.
