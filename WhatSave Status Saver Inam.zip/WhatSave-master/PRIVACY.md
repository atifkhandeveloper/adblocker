### Privacy Policy and Terms of Use

(1) The content you save with this app should be for personal or entertainment purposes only.
You may not use such content for commercial purposes such as promoting products or services, much less may you engage in such practices on behalf of WhatSave or its developers.

(2) WhatSave makes use of Google Analytics to help us detect bugs or application crashes more easily and to identify the features that are most used by our users and deserve higher development priority.
The data collected is closely related to the operation of the app, no personal information about you is ever included.
If you still do not wish to participate, you can disable this feature at any time from the Settings screen.

(3) This application is open source and is available under the GNU General Public License (version 3).
Any contributions or derivative works must be made and released under the terms of this license.

Important Notice:
This application and its developer do not have any relationship or agreement with other companies or trademarks.