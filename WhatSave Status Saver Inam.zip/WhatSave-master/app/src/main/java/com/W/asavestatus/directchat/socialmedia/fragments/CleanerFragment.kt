package com.W.asavestatus.directchat.socialmedia.fragments

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.airbnb.lottie.LottieAnimationView
import com.airbnb.lottie.LottieDrawable
import com.W.asavestatus.directchat.socialmedia.R
import java.io.File

class CleanerFragment : Fragment() {

    private lateinit var btnOptimize: Button
    private lateinit var sizeText: TextView
    private lateinit var fileCountText: TextView
    private lateinit var lottieAnimationView: LottieAnimationView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_cleaner, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        btnOptimize = view.findViewById(R.id.btn_optimize)
        sizeText = view.findViewById(R.id.size_text)
        fileCountText = view.findViewById(R.id.file_count)
        lottieAnimationView = view.findViewById(R.id.lottieAnimationView)

        btnOptimize.setOnClickListener {
            cleanCache()
            animateTextView(sizeText)
            animateTextView(fileCountText)

            lottieAnimationView.setAnimation("loading_animation.json")
            lottieAnimationView.repeatCount = LottieDrawable.INFINITE
            lottieAnimationView.playAnimation()
            lottieAnimationView.visibility = View.VISIBLE

            // Delay before starting cleaning
            Handler(Looper.getMainLooper()).postDelayed({
                lottieAnimationView.setAnimation("cleaning_animation.json")
                lottieAnimationView.repeatCount = LottieDrawable.INFINITE
                lottieAnimationView.playAnimation()

                // Perform cleaning after another delay
                Handler(Looper.getMainLooper()).postDelayed({
                    cleanCache()

                    // Show done animation
//                    lottieAnimationView.setAnimation("done_animation.json")
//                    lottieAnimationView.repeatCount = 0
//                    lottieAnimationView.playAnimation()

                    // Hide animation after playing
                    Handler(Looper.getMainLooper()).postDelayed({
                        lottieAnimationView.cancelAnimation()
                        lottieAnimationView.visibility = View.GONE
                    }, 2000)

                }, 5000) // Delay for cleaning duration

            }, 8000) // Delay before cleaning starts
        }

        displayCacheSize()
    }


    private fun displayCacheSize() {
        val cacheDir = requireContext().cacheDir
        val sizeInBytes = getFolderSize(cacheDir)
        val sizeInGB = sizeInBytes.toDouble() / (1024 * 1024 * 1024)

        sizeText.text = String.format("%.1f", sizeInGB)
        fileCountText.text = "${countFiles(cacheDir)} FILES FOUND"

    }

    private fun cleanCache() {
        val cacheDir = requireContext().cacheDir
        deleteRecursive(cacheDir)
        Toast.makeText(requireContext(), "Cache optimized!", Toast.LENGTH_SHORT).show()
        displayCacheSize()
    }

    private fun deleteRecursive(fileOrDirectory: File) {
        if (fileOrDirectory.isDirectory)
            fileOrDirectory.listFiles()?.forEach { deleteRecursive(it) }

        fileOrDirectory.delete()
    }

    private fun getFolderSize(file: File): Long {
        var size: Long = 0
        if (file.isDirectory) {
            file.listFiles()?.forEach {
                size += getFolderSize(it)
            }
        } else {
            size = file.length()
        }
        return size
    }

    private fun countFiles(file: File): Int {
        var count = 0
        if (file.isDirectory) {
            file.listFiles()?.forEach {
                count += countFiles(it)
            }
        } else {
            count = 1
        }
        return count
    }

    private fun animateTextView(textView: TextView) {
        textView.animate()
            .scaleX(1.2f)
            .scaleY(1.2f)
            .setDuration(150)
            .withEndAction {
                textView.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(150)
                    .start()
            }.start()
    }
}


