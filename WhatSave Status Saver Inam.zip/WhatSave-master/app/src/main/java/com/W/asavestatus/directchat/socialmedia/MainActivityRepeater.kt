package com.W.asavestatus.directchat.socialmedia

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText

class MainActivityRepeater : AppCompatActivity() {

    private lateinit var messageInput: TextInputEditText
    private lateinit var repeatCountSpinner: Spinner
    private lateinit var repeatButton: Button
    private lateinit var repeatedText: TextView
    private lateinit var copyButton: Button
    private lateinit var sendToWhatsappButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_repeater)

        messageInput = findViewById(R.id.messageInput)
        repeatCountSpinner = findViewById(R.id.repeatCountSpinner)
        repeatButton = findViewById(R.id.repeatButton)
        repeatedText = findViewById(R.id.repeatedText)
        copyButton = findViewById(R.id.copyButton)
        sendToWhatsappButton = findViewById(R.id.sendToWhatsappButton)

        // Setup Spinner with repeat options (1 to 10 times)
        val repeatOptions = (1..10).map { it.toString() }.toList()
        val spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, repeatOptions)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        repeatCountSpinner.adapter = spinnerAdapter

        // Handle repeat button click
        repeatButton.setOnClickListener {
            val message = messageInput.text.toString()
            val repeatCount = repeatCountSpinner.selectedItem.toString().toInt()

            if (message.isNotEmpty()) {
                val repeatedMessage = message.repeat(repeatCount)
                repeatedText.text = repeatedMessage
            } else {
                Toast.makeText(this, "Please enter a message", Toast.LENGTH_SHORT).show()
            }
        }

        // Handle copy button click
        copyButton.setOnClickListener {
            val repeatedMessage = repeatedText.text.toString()
            if (repeatedMessage.isNotEmpty()) {
                copyToClipboard(repeatedMessage)
                Toast.makeText(this, "Text copied to clipboard", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "No text to copy", Toast.LENGTH_SHORT).show()
            }
        }

        // Handle Send to WhatsApp button click
        sendToWhatsappButton.setOnClickListener {
            val repeatedMessage = repeatedText.text.toString()
            if (repeatedMessage.isNotEmpty()) {
                sendTextToWhatsApp(repeatedMessage)
            } else {
                Toast.makeText(this, "No text to send", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun copyToClipboard(text: String) {
        // Get the ClipboardManager system service
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Repeated Text", text)
        clipboard.setPrimaryClip(clip)
    }

    private fun sendTextToWhatsApp(text: String) {
        try {
            val sendIntent = Intent()
            sendIntent.action = Intent.ACTION_SEND
            sendIntent.type = "text/plain"
            sendIntent.putExtra(Intent.EXTRA_TEXT, text)
            sendIntent.setPackage("com.whatsapp")

            // Check if WhatsApp is installed
            if (sendIntent.resolveActivity(packageManager) != null) {
                startActivity(sendIntent)
            } else {
                Toast.makeText(this, "WhatsApp is not installed", Toast.LENGTH_SHORT).show()
            }
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "WhatsApp is not installed", Toast.LENGTH_SHORT).show()
        }
    }
}
