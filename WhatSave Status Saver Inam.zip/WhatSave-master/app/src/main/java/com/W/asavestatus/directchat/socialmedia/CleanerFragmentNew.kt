package com.W.asavestatus.directchat.socialmedia


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.W.asavestatus.directchat.socialmedia.databinding.FragmentCleanerNewBinding


class CleanerFragmentNew : Fragment() {

    private var _binding: FragmentCleanerNewBinding? = null
    private val binding get() = _binding!!
    private val viewModel: CleanerViewModel by viewModels()

    private val adapter by lazy { CleanerAdapter() }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCleanerNewBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.cleanerRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.cleanerRecyclerView.adapter = adapter

        viewModel.cleanerItems.observe(viewLifecycleOwner) {
            adapter.submitList(it)
        }

        viewModel.loadData()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
