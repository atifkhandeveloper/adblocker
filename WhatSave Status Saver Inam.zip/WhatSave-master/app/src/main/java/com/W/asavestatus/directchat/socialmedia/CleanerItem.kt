package com.W.asavestatus.directchat.socialmedia

data class CleanerItem(
    val title: String,
    val size: String
)
