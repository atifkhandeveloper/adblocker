package com.W.asavestatus.directchat.socialmedia

import java.io.File

data class MediaFile(
    val file: File,
    val isVideo: Boolean
)
