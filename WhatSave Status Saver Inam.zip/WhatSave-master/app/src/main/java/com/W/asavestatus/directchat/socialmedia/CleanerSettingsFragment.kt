package com.W.asavestatus.directchat.socialmedia

import android.os.Bundle
import android.os.Environment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.W.asavestatus.directchat.socialmedia.databinding.FragmentSettingsCleanerBinding
import java.io.File

class CleanerSettingsFragment : Fragment() {

    private var _binding: FragmentSettingsCleanerBinding? = null
    private val binding get() = _binding!!

    private val mediaDirs = listOf("WhatsApp Images", "WhatsApp Video")

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentSettingsCleanerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnDeleteAll.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Delete All Media")
                .setMessage("Are you sure you want to delete all WhatsApp media?")
                .setPositiveButton("Yes") { _, _ -> deleteMedia() }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun deleteMedia() {
        val baseDir = File(Environment.getExternalStorageDirectory(), "Android/media/com.whatsapp/WhatsApp/Media")
        mediaDirs.forEach { dirName ->
            val dir = File(baseDir, dirName)
            dir.listFiles()?.forEach { it.delete() }
        }
        Toast.makeText(requireContext(), "All media deleted.", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
