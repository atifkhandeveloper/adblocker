package com.W.asavestatus.directchat.socialmedia

import androidx.fragment.app.Fragment
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import java.io.File
import android.os.Environment

import androidx.recyclerview.widget.LinearLayoutManager
import com.W.asavestatus.directchat.socialmedia.databinding.FragmentMediaCleanerBinding

class MediaFragment : Fragment() {

    private var _binding: FragmentMediaCleanerBinding? = null
    private val binding get() = _binding!!
    private val mediaFiles = mutableListOf<MediaFile>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentMediaCleanerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerView.adapter = MediaAdapter(mediaFiles)

//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
//            requestPermissions(arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO), 100)
//        } else {
//            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 100)
//        }

        loadMedia()
    }

    private fun loadMedia() {
        val baseDir = File(Environment.getExternalStorageDirectory(), "Android/media/com.whatsapp/WhatsApp/Media")
        val mediaDirs = listOf("WhatsApp Images", "WhatsApp Video")

        mediaDirs.forEach { dirName ->
            val dir = File(baseDir, dirName)
            if (dir.exists() && dir.isDirectory) {
                dir.listFiles()?.forEach { file ->
                    if (file.isFile) {
                        mediaFiles.add(MediaFile(file, dirName.contains("Video")))
                    }
                }
            }
        }
        binding.recyclerView.adapter?.notifyDataSetChanged()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
