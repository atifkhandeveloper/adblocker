package com.W.asavestatus.directchat.socialmedia

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FolderAdapter(
    private val folderList: List<Pair<String, String>>,
    private val itemClickListener: (String, String) -> Unit
) : RecyclerView.Adapter<FolderAdapter.FolderViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FolderViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(android.R.layout.simple_list_item_2, parent, false)
        return FolderViewHolder(view)
    }

    override fun onBindViewHolder(holder: FolderViewHolder, position: Int) {
        val (folderName, folderPath) = folderList[position]
        holder.folderName.text = folderName
        holder.folderPath.text = folderPath
        holder.itemView.setOnClickListener {
            itemClickListener(folderName, folderPath)
        }
    }

    override fun getItemCount() = folderList.size

    class FolderViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val folderName: TextView = view.findViewById(android.R.id.text1)
        val folderPath: TextView = view.findViewById(android.R.id.text2)
    }
}
