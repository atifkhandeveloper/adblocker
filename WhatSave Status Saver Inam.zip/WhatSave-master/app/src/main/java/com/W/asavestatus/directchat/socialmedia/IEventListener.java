package com.W.asavestatus.directchat.socialmedia;

public interface IEventListener {

    public int eventNotify(int eventType, Object eventObject);
}