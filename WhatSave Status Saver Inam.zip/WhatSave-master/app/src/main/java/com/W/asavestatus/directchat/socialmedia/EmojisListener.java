package com.W.asavestatus.directchat.socialmedia;

public interface EmojisListener {
    void onWpShare(String emojiUnicode);
    void onShare(String emojiUnicode);
    void onCopy(String emojiUnicode);
}
