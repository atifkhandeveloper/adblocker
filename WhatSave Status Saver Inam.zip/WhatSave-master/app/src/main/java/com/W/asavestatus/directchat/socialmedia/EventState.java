package com.W.asavestatus.directchat.socialmedia;

public class EventState {
    public static final int EVENT_AD_LOADED_NATIVE = 1;

    public static final int EVENT_CONSUMED = 1;
    public static final int EVENT_PROCESSED = 2;
    public static final int EVENT_IGNORED = 3;
}