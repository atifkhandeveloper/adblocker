package com.W.asavestatus.directchat.socialmedia.interfaces

import android.view.MenuItem
import com.W.asavestatus.directchat.socialmedia.extensions.StatusMenu
import com.W.asavestatus.directchat.socialmedia.model.Status

/**
 * @author Christians Martínez Alvarado (mardous)
 */
interface IStatusCallback {
    fun showStatusMenu(menu: StatusMenu)
    fun previewStatusesClick(statuses: List<Status>, startPosition: Int)
    fun multiSelectionItemClick(item: MenuItem, selection: List<Status>)
}