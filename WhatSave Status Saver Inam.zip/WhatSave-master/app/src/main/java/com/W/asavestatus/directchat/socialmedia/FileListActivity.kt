package com.W.asavestatus.directchat.socialmedia

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class FileListActivity : AppCompatActivity() {

    private lateinit var fileListTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_file_list)

        fileListTextView = findViewById(R.id.fileListTextView)

        val folderName = intent.getStringExtra("folderName")
        val folderPath = intent.getStringExtra("folderPath")

        val folder = File(getExternalFilesDir(null), folderPath)
        val files = folder.listFiles() ?: emptyArray()

        val fileNames = files.joinToString("\n") { it.name }
        fileListTextView.text = fileNames
    }
}
