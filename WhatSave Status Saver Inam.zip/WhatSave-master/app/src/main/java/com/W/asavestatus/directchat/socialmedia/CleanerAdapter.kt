package com.W.asavestatus.directchat.socialmedia


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.W.asavestatus.directchat.socialmedia.databinding.ItemCleanerBinding


class CleanerAdapter : ListAdapter<CleanerItem, CleanerAdapter.ViewHolder>(DiffCallback()) {

    class ViewHolder(private val binding: ItemCleanerBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: CleanerItem) {
            binding.title.text = item.title
            binding.size.text = item.size
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemCleanerBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class DiffCallback : DiffUtil.ItemCallback<CleanerItem>() {
        override fun areItemsTheSame(oldItem: CleanerItem, newItem: CleanerItem) =
            oldItem.title == newItem.title

        override fun areContentsTheSame(oldItem: CleanerItem, newItem: CleanerItem) =
            oldItem == newItem
    }
}
