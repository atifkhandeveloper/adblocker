/*
 * Copyright (C) 2023 Christians Martínez Alvarado
 *
 * Licensed under the GNU General Public License v3
 *
 * This is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by
 * the Free Software Foundation either version 3 of the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 */
package com.W.asavestatus.directchat.socialmedia

import androidx.room.Room
import com.W.asavestatus.directchat.socialmedia.database.MIGRATION_1_2
import com.W.asavestatus.directchat.socialmedia.database.StatusDatabase
import com.W.asavestatus.directchat.socialmedia.network.ktorHttpClient
import com.W.asavestatus.directchat.socialmedia.repository.CountryRepository
import com.W.asavestatus.directchat.socialmedia.repository.CountryRepositoryImpl
import com.W.asavestatus.directchat.socialmedia.repository.MessageRepository
import com.W.asavestatus.directchat.socialmedia.repository.MessageRepositoryImpl
import com.W.asavestatus.directchat.socialmedia.repository.Repository
import com.W.asavestatus.directchat.socialmedia.repository.RepositoryImpl
import com.W.asavestatus.directchat.socialmedia.repository.StatusesRepository
import com.W.asavestatus.directchat.socialmedia.repository.StatusesRepositoryImpl
import com.W.asavestatus.directchat.socialmedia.storage.Storage
import io.michaelrocks.libphonenumber.android.PhoneNumberUtil
import org.koin.android.ext.koin.androidContext
import org.koin.core.module.dsl.viewModel
import org.koin.dsl.bind
import org.koin.dsl.module

private val networkModule = module {
    single {
        ktorHttpClient()
    }
}

private val dataModule = module {
    single {
        Room.databaseBuilder(androidContext(), StatusDatabase::class.java, "statuses.db")
            .addMigrations(MIGRATION_1_2)
            .build()
    }

    factory {
        get<StatusDatabase>().statusDao()
    }

    factory {
        get<StatusDatabase>().messageDao()
    }
}

private val managerModule = module {
    single {
        PhoneNumberUtil.createInstance(androidContext())
    }
    single {
        Storage(androidContext())
    }
}

private val statusesModule = module {
    single {
        CountryRepositoryImpl(androidContext())
    } bind CountryRepository::class

    single {
        StatusesRepositoryImpl(androidContext(), get(), get())
    } bind StatusesRepository::class

    single {
        MessageRepositoryImpl(get())
    } bind MessageRepository::class

    single {
        RepositoryImpl(get(), get(), get())
    } bind Repository::class
}

private val viewModelModule = module {
    viewModel {
        WhatSaveViewModel(get(), get(), get())
    }
}

val appModules = listOf(networkModule, dataModule, managerModule, statusesModule, viewModelModule)