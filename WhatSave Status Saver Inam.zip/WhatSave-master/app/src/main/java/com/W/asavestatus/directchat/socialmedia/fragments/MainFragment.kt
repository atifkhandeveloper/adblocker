package com.W.asavestatus.directchat.socialmedia.fragments

import android.os.Bundle
import android.provider.Settings
import android.view.MenuItem
import android.view.View
import android.widget.FrameLayout
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.fragment.app.Fragment
import androidx.navigation.NavController
import androidx.navigation.NavDestination
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.navigation.NavigationBarView
import com.google.android.material.navigationrail.NavigationRailView
import com.W.asavestatus.directchat.socialmedia.R
import com.W.asavestatus.directchat.socialmedia.extensions.*
import com.W.asavestatus.directchat.socialmedia.fragments.statuses.StatusesFragment
import android.content.Intent
import androidx.appcompat.app.AlertDialog
import android.content.Context
import android.content.SharedPreferences

class MainFragment : Fragment(R.layout.fragment_main),
    NavigationBarView.OnItemReselectedListener,
    NavController.OnDestinationChangedListener {

    private lateinit var contentView: FrameLayout
    private lateinit var navigationView: NavigationBarView
    private lateinit var childNavController: NavController

    private var windowInsets: WindowInsetsCompat? = null

    // SharedPreferences to persist the dialog shown state
    private lateinit var sharedPreferences: SharedPreferences

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sharedPreferences = requireContext().getSharedPreferences("app_preferences", Context.MODE_PRIVATE)

        contentView = view.findViewById(R.id.main_container)
        contentView.applyHorizontalWindowInsets(left = false)
        navigationView = view.findViewById(R.id.navigation_view)
        navigationView.setOnItemReselectedListener(this)
        if (navigationView is NavigationRailView) {
            navigationView.applyWindowInsets(top = true, left = true)
        }

        requireWindow().decorView.setOnApplyWindowInsetsListener { _, insets ->
            windowInsets = WindowInsetsCompat.toWindowInsetsCompat(insets)
            insets
        }

        childNavController = whichFragment<NavHostFragment>(R.id.main_container).navController
        childNavController.addOnDestinationChangedListener(this)
        navigationView.setupWithNavController(childNavController)

        // Check notification listener permission on view creation
//        checkNotificationPermission()
    }

    override fun onDestinationChanged(controller: NavController, destination: NavDestination, arguments: Bundle?) {
        when (destination.id) {
            R.id.statusesPagerFragment,
            R.id.cleaner,
            R.id.direct_message,
            R.id.sticker,
            R.id.toolsFragment -> hideBottomBar(false)
            else -> hideBottomBar(true)
        }
    }

    override fun onNavigationItemReselected(item: MenuItem) {
        val currentFragment = currentFragment(R.id.main_container)
        if (currentFragment is StatusesFragment) {
            currentFragment.scrollToTop()
        }
    }

    override fun onDestroyView() {
        childNavController.removeOnDestinationChangedListener(this)
        super.onDestroyView()
    }

    private fun hideBottomBar(hide: Boolean) {
        if (hide) navigationView.hide() else navigationView.show()
        if (navigationView is NavigationRailView) return
        val bottomInsets = windowInsets.getBottomInsets()
        val navHeight = resources.getDimensionPixelSize(R.dimen.bottom_nav_height)
        val navHeightWithInsets = navHeight + bottomInsets
        contentView.updatePadding(bottom = if (!hide) navHeightWithInsets else if (!hasR()) bottomInsets else 0)
    }

    // Check notification listener permission
    private fun checkNotificationPermission() {
        // If permission is granted or dialog has already been shown, no need to show it again
        if (isNotificationListenerEnabled() || hasDialogBeenShown()) return

        // Show the dialog
        showNotificationPermissionDialog()
    }

    // Check if notification listener is enabled for this app
    private fun isNotificationListenerEnabled(): Boolean {
        val flat = Settings.Secure.getString(requireContext().contentResolver, "enabled_notification_listeners")
        val colonSplitter = flat?.split(":")
        return colonSplitter?.contains(requireContext().packageName) == true
    }

    // Check if the permission dialog has already been shown
    private fun hasDialogBeenShown(): Boolean {
        return sharedPreferences.getBoolean("notification_permission_dialog_shown", false)
    }

    // Show permission dialog to enable notification listener
    private fun showNotificationPermissionDialog() {
        // Mark the dialog as shown in SharedPreferences
        sharedPreferences.edit().putBoolean("notification_permission_dialog_shown", true).apply()

        AlertDialog.Builder(requireContext())
            .setTitle("Notification Listener Permission Required")
            .setMessage("Please enable notification listener permission to use all features of the app.")
            .setPositiveButton("Go to Settings") { _, _ ->
                val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                startActivityForResult(intent, 1001)
            }
            .setNegativeButton("Cancel", null)
            .setCancelable(false)
            .show()
    }

    // Handle the result when the user comes back from settings after enabling permission
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001) {
            // Recheck permission after returning from the settings screen
            checkNotificationPermission()
        }
    }
}
