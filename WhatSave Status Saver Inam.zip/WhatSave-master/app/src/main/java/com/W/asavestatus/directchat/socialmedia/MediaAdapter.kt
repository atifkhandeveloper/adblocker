package com.W.asavestatus.directchat.socialmedia

import android.media.ThumbnailUtils
import android.net.Uri
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.W.asavestatus.directchat.socialmedia.databinding.ItemMediaBinding

class MediaAdapter(private val files: List<MediaFile>) :
    RecyclerView.Adapter<MediaAdapter.MediaViewHolder>() {

    inner class MediaViewHolder(val binding: ItemMediaBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MediaViewHolder {
        val binding = ItemMediaBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MediaViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MediaViewHolder, position: Int) {
        val mediaFile = files[position]
        val uri = Uri.fromFile(mediaFile.file)
        if (mediaFile.isVideo) {
            holder.binding.thumbnail.setImageBitmap(
                ThumbnailUtils.createVideoThumbnail(
                    mediaFile.file.absolutePath,
                    MediaStore.Images.Thumbnails.MINI_KIND
                )
            )
        } else {
            holder.binding.thumbnail.setImageURI(uri)
        }
        holder.binding.filename.text = mediaFile.file.name
    }

    override fun getItemCount(): Int = files.size
}
