package com.W.asavestatus.directchat.socialmedia


import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class CleanerViewModel : ViewModel() {

    private val _cleanerItems = MutableLiveData<List<CleanerItem>>()
    val cleanerItems: LiveData<List<CleanerItem>> = _cleanerItems

    fun loadData() {
        _cleanerItems.value = listOf(
            CleanerItem("Images", "12 MB"),
            CleanerItem("Videos", "30 MB"),
            CleanerItem("Audio", "8 MB"),
            CleanerItem("Documents", "15 MB")
        )
    }
}
